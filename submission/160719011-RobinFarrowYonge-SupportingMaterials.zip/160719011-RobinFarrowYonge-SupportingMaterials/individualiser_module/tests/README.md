Kinda fell off on the testing there lads. 

Simplistic tests, incredibly un-fancy.

These tests were for the original reconstructing/deconstructing/PCA functions, and as such were tested with the first CLI implementation. Future tests were performed on a per-function basis using the Python interpreter, which is bad I know but things got wet 'n' wild for a little bit up in here. 